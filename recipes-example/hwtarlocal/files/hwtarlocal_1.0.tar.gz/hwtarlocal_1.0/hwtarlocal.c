#include <stdio.h>

int main(void) {
	printf("Hello, World from an application cloned from tar local!\r\n");
	return 0;
}
